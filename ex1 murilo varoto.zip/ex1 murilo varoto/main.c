#include <stdio.h>
#include "livro.h"

int main() {
    struct Livro* lista = NULL;
    int opcao;

    do {
        printf("\nMenu:\n");
        printf("1 - Inserir livro\n");
        printf("2 - Deletar livro\n");
        printf("3 - Mostrar livro mais popular\n");
        printf("4 - Mostrar todos os livros\n");
        printf("5 - Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: {
                char titulo[100];
                char autor[100];
                int disponiveis;
                int emprestados;
                float popularidade;

                printf("Título: ");
                scanf(" %99[^\n]", titulo);
                printf("Autor: ");
                scanf(" %99[^\n]", autor);
                printf("Disponíveis: ");
                scanf("%d", &disponiveis);
                printf("Emprestados: ");
                scanf("%d", &emprestados);

                popularidade = (float) emprestados / disponiveis;

                inserirLivro(&lista, titulo, autor, disponiveis, emprestados, popularidade);
                break;
            }
            case 2: {
                char titulo[100];
                printf("Digite o título do livro a ser deletado: ");
                scanf(" %99[^\n]", titulo);
                removerLivro(&lista, titulo);
                break;
            }
            case 3: {
                struct Livro* maisPopular = livroMaisPopular(lista);
                if (maisPopular != NULL) {
                    printf("Livro mais popular: Título: %s, Autor: %s, Popularidade: %.2f\n",
                           maisPopular->titulo, maisPopular->autor, calcularPopularidade(maisPopular));
                } else {
                    printf("Nenhum livro na lista.\n");
                }
                break;
            }
            case 4:
                printf("\nTodos os livros:\n");
                imprimirLivros(lista);
                break;
            case 5:
                printf("Saindo do programa.\n");
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 5);

    while (lista != NULL) {
        struct Livro* temp = lista;
        lista = lista->proximo;
        free(temp);
    }

    return 0;
}




// PERGUNTA 1: A complexidade de tempo da operação de inserção em uma lista encadeada ordenada é O(n), onde "n" é o número de livros na lista. Isso ocorre porque, no pior caso, a inserção pode exigir percorrer toda a lista para encontrar o local correto para o novo livro.

// PERGUNTA 2: A complexidade de tempo da operação de remoção de um livro da lista encadeada ordenada por popularidade é O(n), onde "n" é o número de livros na lista. Isso ocorre porque, na pior situação, a operação de remoção pode exigir percorrer toda a lista para encontrar o livro a ser removido.

// PERGUNTA 3: Para implementar a consulta do livro mais popular na lista de forma eficiente, é possível adicionar um ponteiro para o livro mais popular atual à medida que insere ou remove livros da lista. Isso evita a necessidade de percorrer toda a lista sempre que você deseja encontrar o livro mais popular.

// PERGUNTA 4: Para imprimir todos os livros ordenados por popularidade em ordem decrescente, você precisa percorrer a lista e imprimir cada livro. Isso requer uma passagem completa por todos os elementos da lista, independentemente de sua ordenação. Portanto, a complexidade de tempo é linear.
