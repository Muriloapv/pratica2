#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "livro.h"

float calcularPopularidade(struct Livro* livro) {
    return livro->popularidade;
}

void inserirLivro(struct Livro** lista, char* titulo, char* autor, int disponiveis, int emprestados, float popularidade) {
    struct Livro* novoLivro = (struct Livro*)malloc(sizeof(struct Livro));
    strncpy(novoLivro->titulo, titulo, sizeof(novoLivro->titulo));
    strncpy(novoLivro->autor, autor, sizeof(novoLivro->autor));
    novoLivro->disponiveis = disponiveis;
    novoLivro->emprestados = emprestados;
    novoLivro->popularidade = popularidade;

    if (*lista == NULL || popularidade > (*lista)->popularidade) {
        novoLivro->proximo = *lista;
        *lista = novoLivro;
    }
    else {
        struct Livro* atual = *lista;

        while (atual->proximo != NULL && popularidade <= atual->proximo->popularidade) {
            atual = atual->proximo;
        }

        novoLivro->proximo = atual->proximo;
        atual->proximo = novoLivro;
    }
}

void removerLivro(struct Livro** lista, char* titulo) {
    struct Livro* atual = *lista;
    struct Livro* anterior = NULL;

    while (atual != NULL) {
        if (strcmp(atual->titulo, titulo) == 0) {
            if (anterior == NULL) {
                *lista = atual->proximo;
            }
            else {
                anterior->proximo = atual->proximo;
            }
            free(atual);
            return;
        }
        anterior = atual;
        atual = atual->proximo;
    }
}

struct Livro* livroMaisPopular(struct Livro* lista) {
    if (lista == NULL) {
        return NULL;
    }

    struct Livro* maisPopular = lista;
    float popularidadeMaxima = calcularPopularidade(lista);

    while (lista != NULL) {
        float popularidadeAtual = calcularPopularidade(lista);
        if (popularidadeAtual > popularidadeMaxima) {
            maisPopular = lista;
            popularidadeMaxima = popularidadeAtual;
        }
        lista = lista->proximo;
    }

    return maisPopular;
}

void imprimirLivros(struct Livro* lista) {
    printf("Livros ordenados por popularidade:\n");
    while (lista != NULL) {
        printf("Título: %s, Autor: %s, Disponíveis: %d, Emprestados: %d, Popularidade: %.2f\n",
               lista->titulo, lista->autor, lista->disponiveis, lista->emprestados, calcularPopularidade(lista));
        lista = lista->proximo;
    }
}
