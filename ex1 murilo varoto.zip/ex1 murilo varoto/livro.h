#ifndef LIVRO_H
#define LIVRO_H

struct Livro {
    char titulo[100];
    char autor[100];
    int disponiveis;
    int emprestados;
    float popularidade;
    struct Livro* proximo;
};

float calcularPopularidade(struct Livro* livro);

void inserirLivro(struct Livro** lista, char* titulo, char* autor, int disponiveis, int emprestados, float popularidade);

void removerLivro(struct Livro** lista, char* titulo);

struct Livro* livroMaisPopular(struct Livro* lista);

void imprimirLivros(struct Livro* lista);

#endif
